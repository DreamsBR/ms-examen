package com.example.empresapc.infraestructure.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.security.Timestamp;


@Entity
@Table(name = "empresa")
@Getter
@Setter
public class EmpresaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "ruc", nullable = false, unique = true)
    private String ruc;

    @Column(name = "razon_social", nullable = false)
    private String razonSocial;

    @Column(name = "estado", nullable = false)
    private Integer estado;

    @Column(name = "nom_comercial")
    private String nomComercial;

    @Column(name = "direccion")
    private String direccion;

    @Column(name = "telefono")
    private String telefono;

    @Column(name = "email")
    private String email;

    @Column(name = "usua_crea", nullable = false)
    private String usuaCrea;

    @Column(name = "date_crea", nullable = false)
    private Timestamp dateCrea;

    @Column(name = "usua_modif")
    private String usuaModif;

    @Column(name = "date_modif")
    private Timestamp dateModif;

    @ManyToOne
    @JoinColumn(name = "cod_tipo_doc", nullable = false)
    private TipoDocumentoEntity tipoDocumento;

    @ManyToOne
    @JoinColumn(name = "cod_tipo_emp", nullable = false)
    private TipoEmpresaEntity tipoEmpresa;

}
