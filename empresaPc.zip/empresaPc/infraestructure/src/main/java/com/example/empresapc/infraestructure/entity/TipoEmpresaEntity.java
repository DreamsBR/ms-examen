package com.example.empresapc.infraestructure.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "tipo_empresa")
@Getter
@Setter
public class TipoEmpresaEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTipoEmpresa;

    @Column(name = "cod_tipo", nullable = false, length = 45)
    private String codTipo;

    @Column(name = "desc_tipo", nullable = false, length = 45)
    private String descTipo;

    @Column(name = "estado")
    private Integer estado;


}
