package com.example.empresapc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresaPcApplicationTests {

	@Test
	void contextLoads() {
	}

}
