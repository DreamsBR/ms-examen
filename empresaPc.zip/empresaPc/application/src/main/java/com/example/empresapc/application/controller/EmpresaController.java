package com.example.empresapc.application.controller;

import com.example.empresapc.domain.aggregates.dto.EmpresaDTO;
import com.example.empresapc.domain.aggregates.request.RequestEmpresa;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v2/empresa")
public interface EmpresaController {

    @PostMapping
    EmpresaDTO crearEmpresa(@RequestBody RequestEmpresa requestEmpresa);

    @GetMapping("/{numDoc}")
    Optional<EmpresaDTO> obtenerEmpresa(@PathVariable String numDoc);

    @GetMapping
    List<EmpresaDTO> obtenerTodosEmpresas();

    @PutMapping("/{id}")
    EmpresaDTO actualizarEmpresa(@PathVariable Long id, @RequestBody RequestEmpresa requestEmpresa);

    @DeleteMapping("/{id}")
    EmpresaDTO eliminarEmpresa(@PathVariable Long id);

}
