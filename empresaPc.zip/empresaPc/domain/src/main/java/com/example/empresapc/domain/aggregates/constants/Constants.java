package com.example.empresapc.domain.aggregates.constants;

public class Constants {
    public static final Integer STATUS_ACTIVE=1;
    public static final Integer STATUS_INACTIVE = 0;
    //AUDIT
    public static final String AUDIT_ADMIN="ADMINTEST";

}
