package com.example.empresapc.domain.aggregates.dto;

public class TipoEmp {
}
