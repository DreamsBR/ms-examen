package com.example.empresapc.domain.aggregates.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseSunat {
    private String ruc;
    private String razonSocial;
    private String nombreComercial;
    private String estado;
}
